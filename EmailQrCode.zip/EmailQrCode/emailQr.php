<?php
if(isset($_POST['submitForm'])) {
    $to = "ticketmaster20200@example.com"; // Adresse email du destinataire
    $subject = "Merci pour votre réservation";
    $message = "Merci pour votre réservation.\n\nNom: ".$_POST['nom']."\nPrénom: ".$_POST['prenom']."\nEmail: ".$_POST['email']."\nNuméro de téléphone: ".$_POST['numero']."\n";

    $headers = "From: ticketmaster20200@example.com\r\n";
    $headers .= "Content-type: text/plain; charset=UTF-8\r\n";

    if(mail($to, $subject, $message, $headers)){
        echo "<p>Email envoyé avec succès !</p>";
    } else {
        echo "<p>Échec de l'envoi de l'email.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Formulaire avec code QR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Vos styles personnalisés */
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 30px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .codeQR img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>

    <h2>Formulaire avec code QR</h2>

    <form action="#" method="post">
        <label for="nom">Nom :</label><br>
        <input type="text" id="nom" name="nom"><br><br>

        <label for="prenom">Prénom :</label><br>
        <input type="text" id="prenom" name="prenom"><br><br>

        <label for="email">Email :</label><br>
        <input type="email" id="email" name="email"><br><br>

        <label for="numero">Numéro de téléphone :</label><br>
        <input type="tel" id="numero" name="numero"><br><br>
       
        <div class="codeQR">
            <img id="qrImage" src="i1.png" alt="Code QR">
        </div><br><br>
        
        <input type="button" value="Générer Code QR" id="generateQR">
        <input type="submit" value="Envoyer par Email" name="submitForm">
    </form>

    <script src="qrcode.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const generateBtn = document.getElementById("generateQR");
            const qrImg = document.getElementById("qrImage");

            generateBtn.addEventListener("click", () => {
                const nom = document.getElementById("nom").value;
                const prenom = document.getElementById("prenom").value;
                const email = document.getElementById("email").value;
                const numero = document.getElementById("numero").value;

                // Création du format vCard pour le code QR
                const dataToEncode = `BEGIN:VCARD\nVERSION:3.0\nN:${nom};${prenom};;;\nEMAIL:${email}\nTEL:${numero}\nEND:VCARD`;

                // Génération du code QR
                qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(dataToEncode)}`;
            });
        });
    </script>
</body>
</html>
