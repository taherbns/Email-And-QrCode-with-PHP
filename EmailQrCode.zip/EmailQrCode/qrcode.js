document.addEventListener("DOMContentLoaded", function () {
    const generateBtn = document.getElementById("generateQR");
    const qrImg = document.getElementById("qrImage");

    generateBtn.addEventListener("click", () => {
        const nom = document.getElementById("nom").value;
        const prenom = document.getElementById("prenom").value;
        const email = document.getElementById("email").value;
        const numero = document.getElementById("numero").value;

        // Création du format vCard pour le code QR
        const dataToEncode = `BEGIN:VCARD\nVERSION:3.0\nN:${nom};${prenom};;;\nEMAIL:${email}\nTEL:${numero}\nEND:VCARD`;

        // Génération du code QR
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(dataToEncode)}`;
    });
});
